/* SPDX-License-Identifier: (GPL-2.0-only OR BSD-2-Clause) */
/* Copyright (C) 2018 Netronome Systems, Inc. */

#ifndef __BPF_TOOL_CFG_H
#define __BPF_TOOL_CFG_H

void dump_xlated_cfg(void *buf, unsigned int len);

#endif /* __BPF_TOOL_CFG_H */
