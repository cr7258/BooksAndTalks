// gcc -c mcount.c
#include <stdio.h>
void  mcount() {        
     printf("Hello World\n");
}

